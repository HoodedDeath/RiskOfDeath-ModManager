Basically SetBuildID but ported to BepInEx plugins

* lets unmodded players join your modded lobby if you are host
* lets you join lobbies whose buildid is either "MOD" or the same as your current steam buildid 

(modded players will be unable to join you unless they have the mod)