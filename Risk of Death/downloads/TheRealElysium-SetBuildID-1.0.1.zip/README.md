# Set Build ID
##### by Elysium

Play with your friends with or without mods with no hassle. Does not enable QuickPlay.

### Installation guide
- Copy the BepInEx Folder to: Risk of Rain 2
- OR place Assembly-CSharp.SetBuildId.MM.dll inside of Risk of Rain 2\BepInEx\monomod  !!!Does NOT go in /plugins!!!

###Changelog:
- v1.0.1, Updated Readme
- v1.0.0, Initial Release

~Elysium